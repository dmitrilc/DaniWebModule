module com.bank.security {
	exports com.bank.security.biometrics;
}