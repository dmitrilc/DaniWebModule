package com.bank.security.biometrics;

public class Fingerprint {}