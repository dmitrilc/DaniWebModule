package com.bank.security.vault;

public class Guard {}